from pathlib import Path

import pytest

from alfred.bridge import try_handle
from alfred.executor import Context
from alfred.focus_mode import PAUSABLE, PROTECTED_PORTS
from alfred.gpu_share.worker import games_running, nvidia
from alfred.tools.apps import list_apps
from alfred.tools.files import delete_file, preview_change
from alfred.tools.gpu_share_tools import _v_reg
from alfred.tools.skills_search import search_skill
from alfred.validators import ValidationError, resolve_allowed


def test_windows_system_still_blocked():
    with pytest.raises(ValidationError):
        resolve_allowed(r"C:\Windows\System32\notepad.exe")


def test_delete_is_dry_without_auth(test_home):
    p = test_home / "Documents" / "x.txt"
    p.write_text("ola", encoding="utf-8")
    r = delete_file({"path": str(p)}, Context("d", authorized=False))
    assert r["dry_run"] is True
    assert p.exists()
    assert str(p) in r["would_delete"][0] or r["would_delete"]


def test_preview_does_not_write(test_home):
    p = test_home / "Documents" / "y.txt"
    p.write_text("v", encoding="utf-8")
    r = preview_change({"path": str(p)}, Context("p", authorized=False))
    assert r["exists"] is True
    assert p.read_text(encoding="utf-8") == "v"


def test_register_worker_rejects_public_ip():
    with pytest.raises(ValidationError):
        _v_reg({"host": "8.8.8.8", "port": 8795})


def test_register_worker_accepts_lan():
    a = _v_reg({"host": "192.168.1.20", "port": 8795})
    assert a["host"] == "192.168.1.20"


def test_protected_ports_never_in_pausable():
    assert PROTECTED_PORTS.isdisjoint(PAUSABLE.keys())
    assert 11434 in PROTECTED_PORTS and 8777 in PROTECTED_PORTS and 8791 in PROTECTED_PORTS


def test_skill_search_finds_local():
    r = search_skill({"query": "hermes operador"}, Context("s", authorized=False))
    assert "local_skills" in r
    assert r["suggested_urls"]


def test_list_apps_shape():
    r = list_apps({}, Context("a", authorized=False))
    names = {x["app"] for x in r["apps"]}
    assert "photoshop" in names and "notepad" in names


def test_router_photoshop_and_focus():
    r = try_handle("Alfred, abre photoshop")
    assert r is not None
    assert r.get("requires_confirmation") is True or r.get("status") in ("planned", "completed", "failed")
    r2 = try_handle("Alfred, modo funcionario")
    assert r2.get("requires_confirmation") is True


def test_nvidia_helper_does_not_crash():
    info = nvidia()
    assert isinstance(info, dict)


def test_games_running_returns_list():
    assert isinstance(games_running(), list)
