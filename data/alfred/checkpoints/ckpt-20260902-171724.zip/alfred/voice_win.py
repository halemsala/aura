"""TTS/STT Windows (SAPI). Sem abrir o microfone sozinho."""
import re
import subprocess
import sys
from pathlib import Path

from . import paths

TTS_FILE = paths.DATA_ROOT / "tts_utterance.txt"
MAX_SPEAK = 500


def _sanitize(text: str) -> str:
    t = re.sub(r"[&|$;<>`]", " ", text or "")
    t = re.sub(r"[^\w\s.,;:!?áéíóúãõâêôçÁÉÍÓÚÃÕÂÊÔÇ\-]", " ", t, flags=re.U)
    return re.sub(r"\s+", " ", t).strip()[:MAX_SPEAK]


def speak(text: str) -> dict:
    if sys.platform != "win32":
        return {"ok": False, "error": "TTS só no Windows"}
    safe = _sanitize(text)
    if not safe:
        return {"ok": False, "error": "texto vazio após sanitizar"}
    TTS_FILE.parent.mkdir(parents=True, exist_ok=True)
    TTS_FILE.write_text(safe, encoding="utf-16")
    ps = (
        "Add-Type -AssemblyName System.Speech; "
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
        f"$t = Get-Content -Raw -Encoding Unicode -LiteralPath '{TTS_FILE}'; "
        "$s.Rate = 0; $s.Speak($t)"
    )
    try:
        p = subprocess.run(
            ["powershell.exe", "-NoLogo", "-NoProfile", "-Command", ps],
            capture_output=True, text=True, timeout=60)
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "timeout TTS 60s"}
    if p.returncode != 0:
        return {"ok": False, "error": (p.stderr or p.stdout or "sapi falhou")[:200]}
    return {"ok": True, "engine": "SAPI", "chars": len(safe)}


def listen(seconds: int = 6) -> dict:
    """STT via SAPI. Pode estar BLOCKED se o reconhecimento Windows não estiver instalado."""
    if sys.platform != "win32":
        return {"ok": False, "blocked": True, "error": "STT só no Windows"}
    sec = max(3, min(int(seconds), 12))
    ps = (
        "Add-Type -AssemblyName System.Speech; "
        "try { "
        "$r = New-Object System.Speech.Recognition.SpeechRecognitionEngine; "
        "$r.SetInputToDefaultAudioDevice(); "
        "$r.LoadGrammar((New-Object System.Speech.Recognition.DictationGrammar)); "
        f"$res = $r.Recognize([TimeSpan]::FromSeconds({sec})); "
        "if($res){ $res.Text } else { '' } "
        "} catch { 'BLOCKED:' + $_.Exception.Message }"
    )
    try:
        p = subprocess.run(
            ["powershell.exe", "-NoLogo", "-NoProfile", "-Command", ps],
            capture_output=True, text=True, timeout=sec + 15)
    except subprocess.TimeoutExpired:
        return {"ok": False, "blocked": True, "error": "timeout STT"}
    out = (p.stdout or "").strip()
    if out.startswith("BLOCKED:") or p.returncode != 0:
        return {"ok": False, "blocked": True,
                "error": out[:200] or (p.stderr or "")[:200],
                "nota": "Instala o reconhecimento de voz do Windows (Definições > Voz) ou usa o chat por texto."}
    if not out:
        return {"ok": True, "text": "", "nota": "nada reconhecido"}
    return {"ok": True, "text": out[:500], "engine": "SAPI"}
